package com.example.eureka;

import java.util.Collection;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {
  
  @RequestMapping(value = "/employee", method=RequestMethod.GET)
  public Employee firstPage(){
    
    Employee emp = new Employee();
    emp.setName("Muneeb");
    emp.setDesignation("intern");
    emp.setEmpId("12");
    emp.setSalary(200);
    
    return emp;
  }
     
}
